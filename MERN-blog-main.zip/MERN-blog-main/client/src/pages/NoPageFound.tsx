function NoPageFound() {
  return (
    <h1 className="text-center text-3xl font-semibold m-4">No page found</h1>
  );
}

export default NoPageFound;
